package com.cg.oicr.dao;

import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.oicr.bean.Claim;
import com.cg.oicr.bean.PolicyDetails;
import com.cg.oicr.bean.Question;
import com.cg.oicr.bean.Users;
import com.cg.oicr.exception.InsuranceException;

public class DaoImplTest {
	
	static DaoImpl dao;
	static Claim claim;
	static PolicyDetails policyDetails;
	static Question question;
	static Users users;
	
	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new DaoImpl();
		claim = new Claim();
		policyDetails=new PolicyDetails();
		question=new Question();
		users=new Users();
	}

	@Test
	public void testLogin() throws SQLException, IOException, InsuranceException, com.cg.oicr.exception.InsuranceException {
		assertNotNull(dao.Login("Venbatch123","Ven@123"));	

	}

	@Test
	public void testLogin1() throws SQLException, IOException, InsuranceException, com.cg.oicr.exception.InsuranceException   {
		assertEquals("USER000",dao.Login("Asha@234","Asha/"));

	}

	
	
	@Test
	public void testQuestions() throws ClassNotFoundException, IOException, InsuranceException, com.cg.oicr.exception.InsuranceException {
		assertNotNull(dao.questions(claim.getClaim_Type()));	
		}

	@Test
	public void testInsert() throws SQLException, IOException, com.cg.oicr.exception.InsuranceException {
		assertNotNull(dao.insert(2019000011,1,"1.1"));
	}

	@Test
	public void testAddHisCustomer() throws IOException, SQLException, InsuranceException, com.cg.oicr.exception.InsuranceException {
		
		assertNotNull(dao.addHisCustomer("Vig@123","Asha@234"));
	}

	@Test
	public void testGetPolicyDetails() throws Exception {
		assertNotNull(dao.getPolicyDetails("Asha@234"));
	}

	@Test
	public void testCreateClaim() throws IOException, SQLException, InsuranceException {
		assertNotNull(dao.createClaim(claim,policyDetails));	
	}

	@Test
	public void testAddDetails() throws ClassNotFoundException, SQLException, Exception {
		assertNotNull(dao.addDetails(users));
	}
	
	
	@Test
	public void testAddDetails1() throws ClassNotFoundException, SQLException, Exception {

	users.setUsername("asd");
	users.setPassword("Sfsa@12");
	users.setRollcode("ADMIN000");
	assertTrue("Values inserted", dao.addDetails(users));
	
	
	}

	@Test
	public void testViewClaim() throws ClassNotFoundException, SQLException, Exception {

		assertNotNull(dao.viewClaim(claim.getClaim_number()));
		}
	
	

}
