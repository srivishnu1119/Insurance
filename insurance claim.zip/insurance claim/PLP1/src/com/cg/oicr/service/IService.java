package com.cg.oicr.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.oicr.bean.Claim;
import com.cg.oicr.bean.PolicyDetails;
import com.cg.oicr.bean.Users;
import com.cg.oicr.exception.InsuranceException;

public interface IService {
	public String Login(String username,String password) throws SQLException, IOException, InsuranceException;
		
	List questions(int a) throws ClassNotFoundException, IOException, InsuranceException;
	
	int insert(long q,int b,String id) throws SQLException, IOException, InsuranceException;

	String addHisCustomer(String user,String agent) throws IOException, SQLException, InsuranceException;
	
	List getPolicyDetails(String name) throws InsuranceException, Exception;
		
	long createClaim(Claim claim,PolicyDetails policy) throws IOException, SQLException, InsuranceException;
	
	public boolean addDetails(Users user) throws ClassNotFoundException, SQLException, InsuranceException, Exception;
	
	public List viewClaim(long claimNo) throws ClassNotFoundException, SQLException, InsuranceException, Exception;
	
	boolean checkUser(String user,String agent) throws ClassNotFoundException, IOException, SQLException ,InsuranceException;
	
	List genReport(long ClaimNo) throws ClassNotFoundException, IOException, SQLException ,InsuranceException;
	
	
}
